﻿using AnimatedGif;
using Aspose.Words.Lists;
using CSharpKit.Maths.PointTracing;
using Data_logic;
using Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Open3D;
using Radar;
using RadarManage.tool;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using wContourDemo;
using wRPC;
using static System.Net.Mime.MediaTypeNames;

namespace RadarManage
{ /// <summary>
  /// 雷达解析
  /// </summary>
    [Route("api/RadarData")]
    public class RadarData_manage : FunctionBase
    {
        config con = new config();
        string Station = "";//雷达站
        string path = AppDomain.CurrentDomain.BaseDirectory;
        DateTime _lasttime = DateTime.Now.AddMinutes(-6);


        Regex rxjson = new Regex(@"(\w+?).json");//json文件
        Regex rxpng = new Regex(@"(\w+?).png");//png文件
        Regex rx = new Regex(@"^(\d{8})$");

        #region 配置管理

        /// <summary>
        /// 阈值信息保存
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.Get, "阈值信息保存")]
        public object submitConfig(string config)
        {
            if (!string.IsNullOrEmpty(config))
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(path + "\\yujingconfig.txt", false, Encoding.UTF8))
                    {
                        sw.Write(config);
                        sw.Close();
                    }
                    return new { code = 200, message = "信息保存成功" };
                }
                catch (Exception ex)
                {
                    return new { code = 200, message = "信息保存失败，" + ex };
                }
            }
            else
            {
                return new { code = 201, message = "参数不能为空" };
            }
        }



       
        /// <summary>
        /// 读取阈值配置
        /// </summary>
        [Authorize]
        [InstallFun(FunAttribute.Get, "读取阈值配置")]
        public object readerConfig(string aa)
        {
            string result = "";
            try
            {
                using (StreamReader sw = new StreamReader(path + "\\yujingconfig.txt", Encoding.UTF8))
                {
                    result = sw.ReadToEnd();
                    sw.Close();
                }
                return new { code = 200, message = "信息读取成功", result = JsonConvert.SerializeObject(JToken.Parse(result)) };
            }
            catch (Exception ex)
            {
                return new { code = 4999, message = "接口调用异常，" + ex };
            }
        }


        /// <summary>
        /// 保存用户信息
        /// </summary>
        /// <param name="tt"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.NONE, "保存用户信息")]
        public object saveUserJson(T_Contacts_Radar tt)
        {
            Contactsradar_manage manage = new Contactsradar_manage();
            try
            {
                bool flag = manage.Add(tt);

                return new { code = 200, message = "执行成功", result = flag };
            }
            catch (Exception ex)
            {
                return new { code = 4999, message = "接口调用异常，" + ex };
            }
        }

        /// <summary>
        /// 修改用户信息
        /// </summary>
        /// <param name="tt"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.NONE, "修改用户信息")]
        public object updateUserJson(T_Contacts_Radar tt)
        {
            Contactsradar_manage manage = new Contactsradar_manage();
            try
            {
                bool flag = manage.Update(tt);

                return new { code = 200, message = "执行成功", result = flag };
            }
            catch (Exception ex)
            {
                return new { code = 4999, message = "接口调用异常，" + ex };
            }
        }

        /// <summary>
        /// 删除用户信息
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.POST, "删除用户信息")]
        public object deleteUserJson(int Id)
        {
            Contactsradar_manage manage = new Contactsradar_manage();
            try
            {
                bool flag = manage.Delete(Id);

                return new { code = 200, message = "执行成功", result = flag };
            }
            catch (Exception ex)
            {
                return new { code = 4999, message = "接口调用异常，" + ex };
            }
        }

        /// <summary>
        /// 获取用户列表
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.Get, "获取用户列表")]
        public object GetUserJson([Param("关键字")] string keyword, [Param("指定时间 YYYY-MM-dd HH:mm:ss")] string start, [Param("结束时间")] string end, int page, int limit)
        {
            Contactsradar_manage manage = new Contactsradar_manage();
            try
            {
                string Areacode = this.Cookies["Areacode"];

                int count = 0;
                var result = manage.GetListByPage(Areacode, keyword, start, end, page, limit, out count);
                return new { code = 200, message = "执行成功", result = result };
            }
            catch (Exception ex)
            {
                return new { code = 4999, message = "接口调用异常，" + ex };
            }
        }

        #endregion

        #region 多个照片合成GIF
        public class PngListBean
        {
            public string ProductType { get; set; }
            public int Interval { get; set; }
            public List<string> plist { get; set; }
        }

        /// <summary>
        /// 多个照片合成GIF
        /// </summary>
        /// <param name="pnglist"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.NONE, "多张照片合并为GIF")]
        public object PngRetuanGIF(PngListBean list)
        {
            try
            {
                //http://172.18.172.172:9012/雷达单站/20230630/1688140440000.PNG
                //D:\Publish\RadarImgsPath

                // 播放延迟，默认设置为 600ms
                int delay = 600;
                if (list.Interval > 0)
                {
                    delay = list.Interval * 1000;
                }

                string Filepaths = "D:\\Publish\\RadarImgsPath\\GIF_Temp\\" + list.ProductType + "\\" + DateTime.Now.ToString("yyyyMMdd") + "\\";
                if (!Directory.Exists(Filepaths))
                {
                    Directory.CreateDirectory(Filepaths);
                }
                Filepaths = Filepaths + DateTime.Now.ToString("yyyyMMddHHmmss") + ".gif";

                using (var gif = AnimatedGif.AnimatedGif.Create(Filepaths, delay))
                {
                    foreach (string imgPath in list.plist)
                    {
                        Bitmap bit = new Bitmap("D:\\Publish\\RadarImgsPath" + imgPath);
                        gif.AddFrame(bit, delay: delay, quality: GifQuality.Bit8);
                    }
                }
                //   \\雷达单站\\20230630\\1688140440000.PNG
                return new { code = 200, message = "操作成功", result = Filepaths.Replace("D:\\Publish\\RadarImgsPath", "") };
            }
            catch (Exception e)
            {
                return new { code = 4999, message = "接口调用异常，" + e, aaaaa = list };
            }
        }


        public RadarData_manage()
        {
            //获取文件信息
            System.IO.StreamReader sr = new System.IO.StreamReader(AppDomain.CurrentDomain.BaseDirectory + "radarconfig.json", Encoding.UTF8);
            string strmode = sr.ReadToEnd();
            sr.Close();
            List<config> configlist = Newtonsoft.Json.JsonConvert.DeserializeObject<List<config>>(strmode);
            if (configlist.Count > 0)
            {
                con = configlist[0];
            }

            Station = con.staion;
        }

      
        //string BitmapToBase64(string imagePath)
        //{
        //    try
        //    {
        //        System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(imagePath);
        //        MemoryStream ms = new MemoryStream();
        //        bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
        //        byte[] arr = new byte[ms.Length];
        //        ms.Position = 0;
        //        ms.Read(arr, 0, (int)ms.Length);
        //        ms.Close();
        //        return "data:image/png;base64," + Convert.ToBase64String(arr);
        //    }
        //    catch (Exception ex)
        //    {
        //        return "";
        //    }
        //}
        string BitmapToBase64(string imagePath)
        {
            try
            {
                FileStream fs = new FileStream(imagePath, FileMode.Open);
                byte[] bt = new byte[fs.Length];
                fs.Read(bt, 0, bt.Length);
                string strBase64 = Convert.ToBase64String(bt);
                fs.Close();
                return "data:image/png;base64," + strBase64;
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
            return "";
        }


        #endregion



        #region 根据雷达风暴追踪，判断是否到达预警线范围

        public class AreaTimer
        {
            private string areaName;
            public string AreaName { get => areaName; set => areaName = value; }

            public DateTime LastTime { get; set; }
        }
        public class PointMode
        {
            public double azi { get; set; }
            public double distance { get; set; }
            public double maxdBZ { get; set; }
            public string message { get; set; }
        }
        public class LineMode
        {
            public int number { get; set; }
            public double mindbz { get; set; }
            /// <summary>
            /// 距离  公里
            /// </summary>
            public double line_km { get; set; }
            /// <summary>
            /// 发送类型：短信、语音
            /// </summary>
            public string line_sendType { get; set; }
            /// <summary>
            /// 接收人
            /// </summary>
            public string line_receUser { get; set; }

            /// <summary>
            /// 接收时间范围
            /// </summary>
            public string start { get; set; }

            public string end { get; set; }
        }

        #endregion

        /// <summary>
        /// 获取风暴核
        /// </summary>
        /// <param name="dbz"></param>
        /// <param name="mindbz">下限阈值</param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.NONE, "获取风暴核")]
        public object AreaTraceGrouping(fileRdn model)
        {
            try
            {
                double[,] dbz = model.data;
                int mindbz = model.mindbz;// 下限阈值
                string pathfile = model.filename;
                string datetime = model.dt;

                using (StreamReader sr = new StreamReader(pathfile, Encoding.GetEncoding("utf-8")))
                {
                    string Str = sr.ReadToEnd();
                    try
                    {
                        fileRdn rdn = JsonConvert.DeserializeObject<fileRdn>(Str);
                        dbz = rdn.data;
                    }
                    catch
                    {
                        dbz = JsonConvert.DeserializeObject<double[,]>(Str);
                    }
                    sr.Close();
                }
                int col = dbz.GetLength(1);
                int row = dbz.GetLength(0);
                isoline iso = new isoline();
                iso.SetCoordinate(col, row, model.minlon, model.maxlon, model.minlat, model.maxlat);
                //iso.SetCoordinate(col, row, 109.66431603171245, 115.25552462686235, 32.2487449238984, 36.853268655275912);
                double lon = 0, lat = 0;

                List<List<TracePoint>> pointEdge = new List<List<TracePoint>>();
                List<TracePoint> centerpoints = new List<TracePoint>();

                #region AreaGrowSmall

                //AreaGrowSmall areaGrowSmall = new AreaGrowSmall(); 
                //CAllAreaInfo[] cAllAreaInfos = areaGrowSmall.AreaGrow(dbz, mindbz);
                //foreach (CAllAreaInfo area in cAllAreaInfos)
                //{
                //    //中心点
                //    iso.ToCoordinate(area.CenterPoint.x, area.CenterPoint.y, ref lon, ref lat);
                //    centerpoints.Add(new TracePoint()
                //    {
                //        Row = (short)area.CenterPoint.x,
                //        Col = (short)area.CenterPoint.y,
                //        Value = (float)dbz[area.CenterPoint.x, area.CenterPoint.y],
                //        Lon = (float)lon,
                //        Lat = (float)lat
                //    });
                //    //点集
                //    PointF[] PointFSet = new PointF[area.Points.Count];
                //    for (int i = 0; i < area.Points.Count; i++)
                //    {
                //        iso.ToCoordinate(area.Points[i].x, area.Points[i].y, ref lon, ref lat);
                //        PointFSet[i] = new PointF() { X = (float)lon, Y = (float)lat };
                //    }
                //    PointF[] listline = GrahamScan.SortPolyPoints(PointFSet, area.Points.Count);

                //    List<TracePoint> pointlist = new List<TracePoint>();
                //    foreach (PointF item in listline)
                //    {
                //        var joo = PointFSet.Select((p, i) => new { i, p }).Where(p => p.p.X == item.X && p.p.Y == item.Y).First();

                //        pointlist.Add(new TracePoint()
                //        {
                //            Row = (short)area.Points[joo.i].x,
                //            Col = (short)area.Points[joo.i].y,
                //            Value = (float)dbz[area.Points[joo.i].x, area.Points[joo.i].y],
                //            Lon = (float)item.X,
                //            Lat = (float)item.Y
                //        });
                //    }
                //    pointEdge.Add(pointlist);
                //}
                #endregion

                #region TracePointGroup method

                TracePointGroup points = new TracePointGroup();

                double[,] dataU = new double[col, row];
                ////翻转数据顺90->水平
                for (int x = 0; x < col; x++)
                {
                    for (int y = 0; y < row; y++)
                    {
                        dataU[x, row - y - 1] = dbz[row - y - 1, x];
                    }
                }

                for (int i = 0; i < col * row; i++)
                {
                    int r = i / row;
                    int c = i % col;

                    double rv = dataU[r, c];
                    if (rv > mindbz)
                    {
                        TracePoint xpoint = new TracePoint
                        {
                            ID = i,
                            Row = (short)r,
                            Col = (short)c,
                            Flag = TracePoint.NotTraced,
                            GroupID = TracePoint.InvalidGroupID,
                            Value = (float)rv,
                        };
                        iso.ToCoordinate(xpoint.Col, xpoint.Row, ref lon, ref lat);

                        xpoint.Lon = (float)lon;
                        xpoint.Lat = (float)lat;

                        points.Add(xpoint);
                    }
                }
                if (points.Count > 0)
                {
                    // 编组
                    TracePointHelper.Grouping(points);

                    // 点组集合
                    List<TracePointGroup> pointGroups = TracePointHelper.PointGroups.FindAll(p => p.Count > 50);

                    // 转换边界行列到经纬度
                    foreach (TracePointGroup ptg in pointGroups)
                    {
                        ptg.Edge = TracePointHelper.EdgeTracing_8(ptg);
                        //TracePointHelper.RowCol2LonLat(radarInfo.Lon, radarInfo.Lat, ptg.Edge);
                        pointEdge.Add(ptg.Edge);
                        //ptg.Edge.Sort((x, y) => x.EdgeIndex < y.EdgeIndex ? -1 : x.EdgeIndex > y.EdgeIndex ? 1 : 0);
                    }
                }
                #endregion

                return new { code = 200, message = "操作成功", result = pointEdge, centerpoint = centerpoints };
            }
            catch (Exception e)
            {
                return new { code = 4999, message = "接口调用异常" + e.Message };
            }
            //End
        }

        /// <summary>
        /// 雷达剖面
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.NONE, "雷达剖面")]
        public object RadarPouMian(parameter parameters)
        {
            string datetime = parameters.datetime;
            string Name = parameters.Name;//Z9451.20200318.111531.AR2
            string _PathFile = "";
            try
            {
                string filter = DateTime.Parse(datetime).ToString("yyyyMMddHHmm");//Z_RADR_I_Z9371_20200517235400_O_DOR_SA_CAP.bin
                _PathFile = GetDirFiles(con.pathfile + @"\" + con.staion, Name, filter);
                if (string.IsNullOrEmpty(_PathFile))
                {
                    return new { code = 201, message = "未找到数据" };
                }
                //20220919.0356
                //_PathFile = @"F://Z_RADR_I_Z9351_20220928054100_O_DOR_CC_CAP.bin";
                #region 解压文件
                try
                {
                    FileInfo fii = new FileInfo(_PathFile);
                    if (fii.Extension.Contains(".bz2"))
                    {
                        string pwd = "";                           //  解压密码 
                        string zipFileName = fii.FullName;         //  需要被解压的Zip文件 
                        string exeFileName = AppDomain.CurrentDomain.BaseDirectory + @"7-Zip\7z.exe";
                        string commands = String.Format("\"{0}\" e \"{1}\" -y -p{2} -o\"{3}\"", exeFileName, zipFileName, pwd, fii.Directory.FullName);

                        string[] sret = CSharpKit.Utils.ProcessHelper.ExecCommand(commands);  // 运行解压程序
                        string exeFilename = System.IO.Path.Combine(fii.Directory.FullName, fii.Name.Substring(0, fii.Name.Length - fii.Extension.Length));
                        File.Delete(fii.FullName);
                        _PathFile = _PathFile.Replace(fii.Extension, "");
                    }
                }
                catch { }
                #endregion

                RadarController controller = new RadarController();
                controller.Maxvalidradius = 960;
                controller.ReadRadar(_PathFile, vendor.CINRADCC, con.center[1], con.center[0], con.center[2]);

                List<Pdtata> pdtatas = new List<Pdtata>();
                Pdtata pd = null;
                int mindbz = 0;
                if (parameters.type == "VEL")//速度
                {
                    mindbz = -25;
                    pd = controller.ppi(Datatype.V);
                    for (int i = 0; i < controller.MaxDBZCutNum; i++)
                    {
                        //Pdtata pd2 = controller.ppi(Datatype.V, i, 512, 512, controller.resolution);
                        Pdtata pd2 = controller.ppi(Datatype.V, i, 800, 800, controller.resolution);
                        pdtatas.Add(pd2);
                    }
                }
                else if (parameters.type == "SPW")//普宽
                {
                    pd = controller.ppi(Datatype.W);
                    for (int i = 0; i < controller.MaxDBZCutNum; i++)
                    {
                        Pdtata pd2 = controller.ppi(Datatype.W, i, 800, 800, controller.resolution);
                        pdtatas.Add(pd2);
                    }
                }
                else if (parameters.type == "R") //反射率
                {
                    pd = controller.ppi(Datatype.R);
                    for (int i = 0; i < controller.MaxDBZCutNum; i++)
                    {
                        Pdtata pd2 = controller.ppi(Datatype.R, i, 800, 800, controller.resolution);
                        pdtatas.Add(pd2);
                    }
                }
                else if (parameters.type == "CR") //反射率
                {
                    parameters.type = "BCR";
                    pd = controller.ppi(Datatype.CR);
                    for (int i = 0; i < controller.MaxDBZCutNum; i++)
                    {
                        Pdtata pd2 = controller.ppi(Datatype.CR, i, 800, 800, controller.resolution);
                        pdtatas.Add(pd2);
                    }
                }
                else
                {
                    return new { code = 201, message = "不支持剖面" };
                }

                //Bitmap bitmap = null;
                WeaveHelper.conver.MapHelper mapHelper = new WeaveHelper.conver.MapHelper();
                List<double> listX = pd.Max_min_coordinates.Select(p => p.X).ToList();
                List<double> listY = pd.Max_min_coordinates.Select(p => p.Y).ToList();
                mapHelper.init(800, 800, listX.Min(), listX.Max(), listY.Min(), listY.Max());
                WeaveHelper.PointD sPoint = mapHelper.ToScreen(parameters.sLon, parameters.sLat);
                WeaveHelper.PointD ePoint = mapHelper.ToScreen(parameters.eLon, parameters.eLat);

                //剖面方法
                dynamic dynamicdb = Reconstruction_3D.Pdtata_to_datasCAPPI(pdtatas, 20, mindbz);//最大反射率，和最大反射率高度

                var datas = Reconstruction_3D.Datas_Cubic_Grid_interpolationMedian(dynamicdb.Item1);
                //把经纬度，转换成x,y
                double[,] profiledata = Reconstruction_3D.profile(datas, (int)sPoint.X, (int)sPoint.Y, (int)ePoint.X, (int)ePoint.Y);

                //WeaveHelper.matical.interpolation interpolation = new WeaveHelper.matical.interpolation();
                //profiledata= interpolation.Calculate_2Dto2D(profiledata, WeaveHelper.matical.interpolationoperator.Bilinear, 600, 400);
                string filename = AppDomain.CurrentDomain.BaseDirectory + "profiledata .png";
                ColorRda.Savefile(profiledata, filename, parameters.type);
                //bitmap = (Bitmap)Image.FromFile(filename);
                //if (bitmap != null)
                //{
                //    MemoryStream ms = new MemoryStream();
                //    bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                //    byte[] bytes = ms.ToArray();
                //    ms.Close();
                //    string result = "data:image/png;base64," + Convert.ToBase64String(bytes);
                //    //bitmap.Save("d:\\pmt.png");
                //    bitmap.Dispose();
                //    jo["data"] = result;

                //}

                return new { code = 200, message = "操作成功", result = profiledata, maxdb = dynamicdb.Item2, maxdbh = dynamicdb.Item3 };
            }
            catch (Exception e)
            {
                return new { code = 4999, message = "解析失败" + e.ToString(), dd = Name, ddd = _PathFile, dddd = datetime };
            }
        }


        /// <summary>
        /// 分层获取
        /// </summary>
        /// <param name="paramss"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.NONE, "分层获取")]
        public object GetFencengRdnData(parameter paramss)
        {
            try
            {
                string jsonfile = paramss.Name;
                string datetime = paramss.datetime;
                float ly = paramss.data;//层数1-4
                if (jsonfile != "")
                {
                    FileInfo fi = new FileInfo(jsonfile);

                    if (fi != null)
                    {
                        string dir = fi.DirectoryName + @"\Y\";
                        FileInfo[] fiipng = new DirectoryInfo(dir).GetFiles("*.png");
                        string fjson = fi.Name.Replace(fi.Extension, "") + "_" + ly + ".json";
                        string fpng = fi.Name.Replace(fi.Extension, "").Split('_')[1] + "_" + ly;
                        fiipng = fiipng.Where(p => p.Name.Contains(fpng)).ToArray();
                        if (fiipng.Length > 0)
                        {
                            fileRdn fr = new fileRdn();
                            using (StreamReader sr = new StreamReader(dir + fjson, Encoding.GetEncoding("utf-8")))
                            {
                                string str = sr.ReadToEnd();
                                fr = JsonConvert.DeserializeObject<fileRdn>(str);
                                sr.Close();
                            }
                            fr.data = null;
                            fr.Imagedata = BitmapToBase64(fiipng[0].FullName);
                            fr.filename = dir + fjson;

                            return new { code = 200, message = "操作成功", result = fr };
                        }
                    }
                }
                return new { code = 200, message = "操作成功", result = "" };
            }
            catch (Exception e)
            {
                return new { code = 4999, message = "接口调用异常" + e.Message };
            }
        }


        /// <summary>
        /// 产品数据图
        /// </summary>
        /// <param name="Type"></param>
        /// <returns></returns>
        [Authorize]
        [InstallFun(FunAttribute.POST, "产品数据图")]
        public object GetRadarImageData(string Type)
        {
            List<fileRdn> list = new List<fileRdn>();
            fileInfo jolist = new fileInfo();
            string lastTime = null;

            try
            {
                DirectoryInfo[] dires = new DirectoryInfo(con.topathfile + con.staion).GetDirectories();
                if (dires.Length > 0)
                {
                    dires = dires.Where(p => rx.Match(p.Name).Success).OrderByDescending(p => p.Name).ToArray();

                    string Dirpath = dires[0].FullName + @"\" + Type + @"\";
                    FileInfo[] filelist = new DirectoryInfo(Dirpath).GetFiles();
                    if (filelist.Length > 0)
                    {
                        FileInfo[] jsonfilelist = filelist.Where(p => rxjson.Match(p.Name).Success).OrderByDescending(p => p.Name).Take(10).ToArray();
                        filelist = filelist.Where(p => rxpng.Match(p.Name).Success).OrderByDescending(p => p.Name).Take(10).ToArray();

                        for (int i = 0; i < filelist.Length; i++)
                        {
                            FileInfo fi = filelist[i];
                            try
                            {
                                fileRdn rdn = new fileRdn();
                                rdn.maxlon = con.maxlon;
                                rdn.minlon = con.minlon;
                                rdn.maxlat = con.maxlat;
                                rdn.minlat = con.minlat;

                                var tJson = File.ReadAllText(jsonfilelist[i].FullName);
                                var tData = JsonConvert.DeserializeObject<config>(tJson);
                                rdn.maxlon = tData.maxlon;
                                rdn.minlon = tData.minlon;
                                rdn.maxlat = tData.maxlat;
                                rdn.minlat = tData.minlat;

                                rdn.Imagedata = BitmapToBase64(fi.FullName);
                                rdn.filename = jsonfilelist[i].FullName;
                                DateTime date;
                                if (DateTime.TryParseExact(fi.Name.Split('.')[0].Split('_')[1], "yyyyMMddHHmm", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date))
                                {
                                    //rdn.dt = date.ToString("yyyy-MM-dd HH:mm:ss");
                                    rdn.dt = date.AddHours(+8).ToString("yyyy-MM-dd HH:mm:ss");
                                }
                                if (lastTime == null)
                                {
                                    //lastTime = DateTime.Parse(rdn.dt).ToString("yyyy-MM-dd HH:mm:ss");
                                    lastTime = DateTime.Parse(rdn.dt).AddHours(+8).ToString("yyyy-MM-dd HH:mm:ss");
                                }
                                if (DateTime.Parse(lastTime) < DateTime.Parse(rdn.dt))
                                {
                                    //lastTime = DateTime.Parse(rdn.dt).ToString("yyyy-MM-dd HH:mm:ss");
                                    lastTime = DateTime.Parse(rdn.dt).AddHours(+8).ToString("yyyy-MM-dd HH:mm:ss");
                                }
                                list.Add(rdn);
                            }
                            catch (Exception ex) { }

                        }
                    }
                    list = list.OrderBy(p => DateTime.Parse(p.dt)).ToList();
                    jolist.nowtime = DateTime.Parse(lastTime).AddHours(+8).ToString("yyyy-MM-dd HH:mm:ss");
                    jolist.data = list;
                }
                //外推数据-外推暂时不用
                try
                {
                    //List<fileRdn> wtlist = new List<fileRdn>();
                    //string wtpath = Type == "CR" ? "BCR" : Type;
                    //string wtDirpath = con.topathfile + con.staion + @"\Waitui\" + wtpath + @"\";
                    //if (Directory.Exists(wtDirpath))
                    //{
                    //    FileInfo[] wtfilelist = new DirectoryInfo(wtDirpath).GetFiles();
                    //    if (wtfilelist.Length > 0)
                    //    {
                    //        FileInfo[] jsonfilelist = wtfilelist.Where(p => rxjson.Match(p.Name).Success).OrderByDescending(p => p.Name).ToArray();
                    //        FileInfo[] pngfilelist = wtfilelist.Where(p => rxpng.Match(p.Name).Success).OrderByDescending(p => p.Name).ToArray();

                    //        for (int i = 0; i < jsonfilelist.Length; i++)
                    //        {
                    //            FileInfo fi = jsonfilelist[i];
                    //            try
                    //            {
                    //                fileRdn rdn = new fileRdn();
                    //                rdn.maxlon = con.maxlon;
                    //                rdn.minlon = con.minlon;
                    //                rdn.maxlat = con.maxlat;
                    //                rdn.minlat = con.minlat;
                    //                DateTime date;//wt_20200318121700.png

                    //                if (DateTime.TryParseExact(fi.Name.Split('.')[0], "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date))
                    //                {
                    //                    rdn.dt = date.ToString("yyyy-MM-dd HH:mm:ss");
                    //                }
                    //                if (DateTime.Parse(rdn.dt) > DateTime.Parse(lastTime))
                    //                {
                    //                    rdn.Imagedata = BitmapToBase64(pngfilelist[i].FullName);
                    //                    rdn.filename = fi.FullName;

                    //                    wtlist.Add(rdn);
                    //                }
                    //            }
                    //            catch (Exception EE) { }

                    //        }
                    //    }
                    //    //排序
                    //    wtlist = wtlist.OrderBy(p => DateTime.Parse(p.dt)).ToList();
                    //}
                    //jolist.data = jolist.data.Concat(wtlist).ToList();
                }
                catch (Exception ex)
                {
                    System.IO.StreamWriter swr = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "/log.txt", false);
                    swr.WriteLine("error:" + ex.Message);
                    swr.Close();
                }
                return new { code = 200, message = "操作成功", result = jolist };
            }
            catch (Exception e)
            {
                return new { code = 4999, message = "接口调用异常" + e.Message };
            }
        }


        /// <summary>
        /// 获取指定文件信息
        /// </summary>
        /// <param name="path"></param>
        /// <param name="filename"></param>
        /// <returns></returns>
        private static string GetDirFiles(string path, string filename, string filter)
        {
            string fullpath = "";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            DirectoryInfo[] dirs = new DirectoryInfo(path).GetDirectories();
            if (dirs.Length > 0)
            {
                dirs = dirs.OrderByDescending(p => p.Name).Take(2).ToArray();
                foreach (DirectoryInfo item in dirs)
                {
                    //获取文件
                    FileInfo[] files = new DirectoryInfo(item.FullName).GetFiles();
                    if (files.Length > 0)
                    {
                        foreach (FileInfo fi in files)
                        {
                            if (fi.Name.Contains(filename) || (fi.Name.Contains(filter) && filter != ""))
                            {
                                fullpath = fi.FullName;
                                break;
                            }
                        }
                    }
                    if (fullpath != "")
                    {
                        break;
                    }
                }
            }
            return fullpath;
        }


        #region Bean
        public class SD
        {
            public double data { get; set; }
            public string lng { get; set; }
            public string lat { get; set; }
            public string x { get; set; }
            public string y { get; set; }
        }
        public class config
        {
            public double[] center;
            public int ulc = -8;
            public string file = "";
            public string staion = "";
            public string pathfile = "";
            public string topathfile = "";
            public string waituipath = "";
            public DateTime lasttime;
            public double minlon;
            public double minlat;
            public double maxlon;
            public double maxlat;
            public double zorehg = 3.2;//O度层高度，单位KM
            public double subzero20hg = 6.5;//-20度层高度，单位KM
        }
        public class parameter
        {
            public string type { get; set; }
            public string Name { get; set; }
            public string datetime { get; set; }
            public string dataCode { get; set; }
            public string areacode { get; set; }
            //点2
            public double sLon { get; set; }
            public double sLat { get; set; }
            public double eLon { get; set; }
            public double eLat { get; set; }
            //
            public float data = 0;
        }
        public class fileInfo
        {
            public string nowtime { get; set; }
            public List<fileRdn> data { get; set; }
        }
        public class fileRdn
        {
            public double[,] data { get; set; }
            public int mindbz { get; set; }
            public double minlon { get; set; }
            public double minlat { get; set; }
            public double maxlon { get; set; }
            public double maxlat { get; set; }
            public string dt { get; set; }
            public string Imagedata { get; set; }
            public string filename { get; set; }
        }
        #endregion
    }
}
