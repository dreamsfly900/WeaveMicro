﻿using CSharpKit.Maths;
using CSharpKit.Maths.PointTracing;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.IO;

namespace RadarManage.tool
{
    public class radardataBASE
    {
        public double[] center;
        public double minlon;
        public double maxlon;
        public double minlat;
        public double maxlat;
        public double[,] data;
        public List<double[,]> DBZ;
        public List<double[,]> H;
        public DateTime dt;
        public storm[] storms;
    }

    [Serializable]
    public class radardatamode
    {
        public double[] center;
        public double minlon;
        public double maxlon;
        public double minlat;
        public double maxlat;
        public double[,] data;
        public DateTime dt;
        public storm[] storms;
        public string name;
    }
    public class storm
    {
        public string ID;
        public int x;
        public int y;
        public int dbz = 0;
        public Double speed;
        public Double direction;
        public DateTime dt;

    }
    public class BCR
    {
        double[,] THEmedian(double[,] data)
        {
            int x, y;
            double[] p = new double[9]; //最小处理窗口3*3
            double s;
            //byte[] lpTemp=new BYTE[nByteWidth*nHeight];
            int i, j;
            var row = data.GetLength(0);
            var clos = data.GetLength(1);
            //--!!!!!!!!!!!!!!下面开始窗口为3×3中值滤波!!!!!!!!!!!!!!!!
            for (y = 1; y < clos - 1; y++) //--第一行和最后一行无法取窗口
            {
                for (x = 1; x < row - 1; x++)
                {
                    if (data[x, y] <= 0)
                    {
                        //取9个点的值
                        p[0] = data[x - 1, y - 1];
                        p[1] = data[x, y - 1];
                        p[2] = data[x + 1, y - 1];
                        p[3] = data[x - 1, y];
                        p[4] = data[x, y];
                        p[5] = data[x + 1, y];
                        p[6] = data[x - 1, y + 1];
                        p[7] = data[x, y + 1];
                        p[8] = data[x + 1, y + 1];
                        //计算中值
                        for (j = 0; j < 5; j++)
                        {
                            for (i = j + 1; i < 9; i++)
                            {
                                if (p[j] > p[i])
                                {
                                    s = p[j];
                                    p[j] = p[i];
                                    p[i] = s;
                                }
                            }
                        }
                        ////      if (bmpobj.GetPixel(x, y).R < dgGrayValue)
                        ////  bmpobj.SetPixel(x, y, Color.FromArgb(p[4], p[4], p[4]));    //给有效值付中值
                        data[x, y] = p[4];
                    }
                    //  data[x, y] = (p[0] + p[1] + p[2] + p[3] + p[4] + p[5] + p[6] + p[7] + p[8]) / 9;
                }
            }
            return data;
        }


        /// <summary>
        /// 回波顶高
        /// </summary>
        /// <returns></returns>
        public radardatamode getET(radardataBASE rdm, List<double[,]> listdbz, List<double[,]> listhg)
        {
            radardatamode rdma = new radardatamode();
            rdma.dt = rdm.dt;
            rdma.maxlat = rdm.maxlat;
            rdma.maxlon = rdm.maxlon;
            rdma.minlat = rdm.minlat;
            rdma.minlon = rdm.minlon; rdma.center = rdm.center;
            double[,] vg = null;
            double[,] hg = null;
            for (int i = 0; i < listdbz.Count; i++)
            {
                double[,] tdbz = listdbz[i];
                double[,] thg = listhg[i];
                if (vg == null)
                {
                    vg = new double[tdbz.GetLength(0), tdbz.GetLength(1)];
                    hg = new double[tdbz.GetLength(0), tdbz.GetLength(1)];
                }

                for (int ii = 0; ii < tdbz.GetLength(0); ii++)
                {
                    for (int j = 0; j < tdbz.GetLength(1); j++)
                    {
                        if (tdbz[ii, j] > 18.6 && tdbz[ii, j] > vg[ii, j])
                        {
                            vg[ii, j] = Math.Round(tdbz[ii, j], 1);
                            hg[ii, j] = Math.Round(thg[ii, j], 1);
                        }

                    }
                }
            }
            rdma.data = hg;
            return rdma;
        }

        double[,] dbzdata(double[,] grid)
        {
            double[,] dbz = new double[grid.GetLength(0), grid.GetLength(1)];

            for (int ii = 0; ii < grid.GetLength(0); ii++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    dbz[ii, j] = Math.Round(grid[511 - ii, j], 1);
                }
            }
            return dbz;
        }
        /// <summary>
        /// 风暴核
        /// </summary>
        /// <param name="dbz"></param>
        /// <returns></returns>
        public List<List<TracePoint>> AreaTraceGrouping(double[,] dbz, double mindbz, double[] center)
        {
            try
            {
                TracePointGroup points = new TracePointGroup();

                int col = dbz.GetLength(1);
                int row = dbz.GetLength(0);

                KPolar Polar = new KPolar(center[0], center[1]);
                for (int i = 0; i < col * row; i++)
                {
                    int r = i / col;
                    int c = i % col;

                    double rv = dbz[r, c];
                    if (rv > mindbz)
                    {
                        TracePoint xpoint = new TracePoint
                        {
                            ID = i,
                            Row = (short)(i / col),
                            Col = (short)(i % col),
                            Flag = TracePoint.NotTraced,
                            GroupID = TracePoint.InvalidGroupID,
                            Value = (float)rv,
                        };
                        double lon = 0, lat = 0;
                        Polar.XY2LonLat(xpoint.Col, xpoint.Row, out lon, out lat);
                        //iso.ToCoordinate(xpoint.Col, xpoint.Row, ref lon, ref lat);

                        xpoint.Lon = (float)lon;
                        xpoint.Lat = (float)lat;

                        points.Add(xpoint);
                    }
                }
                List<List<TracePoint>> pointEdge = new List<List<TracePoint>>();
                if (points.Count > 0)
                {
                    // 编组
                    TracePointHelper.Grouping(points);
                    // 点组集合
                    List<TracePointGroup> pointGroups = TracePointHelper.PointGroups.FindAll(p => p.Count > 20);
                    // 转换边界行列到经纬度
                    foreach (TracePointGroup ptg in pointGroups)
                    {
                        ptg.Edge = TracePointHelper.EdgeTracing_8(ptg);
                        pointEdge.Add(ptg.Edge);
                        //ptg.Edge.Sort((x, y) => x.EdgeIndex < y.EdgeIndex ? -1 : x.EdgeIndex > y.EdgeIndex ? 1 : 0);
                    }
                }
                return pointEdge;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        //基本反射率
        public radardatamode getREF(string _pathFile)
        {
            radardatamode rdm = new radardatamode();

            try
            {
                //IProvider provider = new MetradFileProvider(_pathFile, null);

                //var rfile = provider.DataInstance as MetradFile;
                ////var alg = rfile.Algorithm as MetradFileAlgorithm;
                //var dataInfo = rfile.DataInfo as MetradFileDataInfo;
                //var processor = rfile.Processor as MetradFileProcessor;

                //var CenterLatitude = (dataInfo).Polar.CenterLatitude;
                //var CenterLongitude = (dataInfo).Polar.CenterLongitude;

                //rdm.dt = ((CSharpKit.Data.DataInfo)rfile.DataInfo).DateTime;

                //double lon0 = 0, lat0 = 0, lon1 = 0, lat1 = 0, lon2 = 0, lat2 = 0;

                //dataInfo.Polar.XY2LonLat(0, 0, out lon0, out lat0);
                ////map.WorldToView(ref lon0, ref lat0);
                //dataInfo.Polar.XY2LonLat(512, 0, out lon1, out lat1);
                ////map.WorldToView(ref lon1, ref lat1);
                //dataInfo.Polar.XY2LonLat(0, 512, out lon2, out lat2);
                ////map.WorldToView(ref lon2, ref lat2);

                ////=======================================
                //rdm.center = new double[] { CenterLongitude, CenterLatitude };

                //rdm.maxlat = lat0;//dataInfo.GridInfo.MaxY;
                //rdm.minlat = lat2;//dataInfo.GridInfo.MinY;
                //rdm.maxlon = lon1; //dataInfo.GridInfo.MaxX;
                //rdm.minlon = lon0;//dataInfo.GridInfo.MinX;

                //processor.Building(RADBDP.CreateObject(MetradDataCode.REF, MetradCut.CUT01, false, false));
                //IGridData<double> Gridata = processor.PPI2GridData(MetradDataCode.REF, MetradCut.CUT01);

                //rdm.data = dbzdata(Gridata.Elements);
                //Bitmap bitmap = rfile.ProductImage[(int)MetradDataCode.REF] as Bitmap;
                //bitmap.MakeTransparent();
                //if (bitmap != null)
                //{

                //    MemoryStream ms = new MemoryStream();
                //    bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                //    byte[] bytes = ms.ToArray();
                //    ms.Close();
                //    string result = "data:image/png;base64," + Convert.ToBase64String(bytes);
                //    rdm.name = result;
                //    bitmap.Dispose();
                //}
                ////btmap.Save("d:\\12.png");

                return rdm;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        //速度、普宽、冰雹指数
        public radardatamode getOtherRdn(radardataBASE rdm, string _pathFile, string Code, int rCUT, string savepath)
        {
            radardatamode rdma = new radardatamode();
            rdma.dt = rdm.dt;
            rdma.maxlat = rdm.maxlat;
            rdma.maxlon = rdm.maxlon;
            rdma.minlat = rdm.minlat;
            rdma.minlon = rdm.minlon;

            try
            {
                //    MetradCut CUT = (MetradCut)rCUT;
                //    IProvider provider = new MetradFileProvider(_pathFile, null);

                //    var rfile = provider.DataInstance as MetradFile;
                //    //var alg = rfile.Algorithm as MetradFileAlgorithm;
                //    var dataInfo = rfile.DataInfo as MetradFileDataInfo;
                //    var processor = rfile.Processor as MetradFileProcessor;
                //    if (Code == "BCR")
                //    {
                //        processor.Building(RADBDP.CreateObject(MetradDataCode.CREF, CUT, false, false));

                //        IGridData<double> Gridata = processor.PPI2GridData(MetradDataCode.CREF, (MetradCut)CUT);

                //        //数据
                //        rdma.data = dbzdata(Gridata.Elements);
                //    }
                //    if (Code == "VEL")
                //    {
                //        processor.Building(RADBDP.CreateObject(MetradDataCode.VEL, CUT, false, false));

                //        IGridData<double> Gridata = processor.PPI2GridData(MetradDataCode.VEL, (MetradCut)CUT);

                //        //数据
                //        rdma.data = dbzdata(Gridata.Elements);

                //    }
                //    if (Code == "VIL")
                //    {
                //        processor.Building(RADBDP.CreateObject(MetradDataCode.VIL, CUT, false, false));

                //        IGridData<double> Gridata = ((rfile.ProductData) as Cappi).GridData;
                //        //数据
                //        rdma.data = dbzdata(Gridata.Elements);
                //    }
                //    if (Code == "SPW") //普宽
                //    {
                //        processor.Building(RADBDP.CreateObject(MetradDataCode.SPW, CUT, false, false));

                //        IGridData<double> Gridata = processor.PPI2GridData(MetradDataCode.SPW, (MetradCut)CUT);

                //        //数据
                //        rdma.data = dbzdata(Gridata.Elements);

                //    }
                //    if (Code == "SHI") //冰雹指数
                //    {
                //        processor.Building(RADBDP.CreateObject(MetradDataCode.SHI, 0.0f, 0.0f, false, false));

                //        IGridData<double> prd = ((rfile.ProductData) as Cappi).GridData;

                //        //数据
                //        rdma.data = dbzdata(prd.Elements);
                //        //保存图片
                //        try
                //        {
                //            //Bitmap btmap = (rfile.ProductImage[(int)MetradDataCode.SHI]) as Bitmap;
                //            //btmap.MakeTransparent();

                //            //btmap.Save(savepath + "SHI_" + rdm.dt.ToString("yyyyMMddHHmm") + ".png");
                //            //btmap.Dispose();
                //        }
                //        catch { }
                // }
                return rdma;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        /// <summary>
        /// VIL
        /// </summary>
        /// <param name="rdm"></param>
        /// <param name="listdbz"></param>
        /// <param name="listhg"></param>
        /// <returns></returns>
        public radardatamode getVIL(radardataBASE rdm, List<double[,]> listdbz, List<double[,]> listhg)
        {
            double[,] dbz = null;
            try
            {
                radardatamode rdma = new radardatamode();
                rdma.dt = rdm.dt;
                rdma.maxlat = rdm.maxlat;
                rdma.maxlon = rdm.maxlon;
                rdma.minlat = rdm.minlat;
                rdma.minlon = rdm.minlon;


                double[,] dbzhg = null;
                double[,] vil = null;
                for (int i = 0; i < 9; i++)
                {
                    double[,] vg = listdbz[i];
                    double[,] hg = listhg[i];


                    if (dbz == null)
                    {
                        dbz = new double[vg.GetLength(0), vg.GetLength(1)];
                        dbzhg = new double[vg.GetLength(0), vg.GetLength(1)];
                        vil = new double[vg.GetLength(0), vg.GetLength(1)];
                    }
                    if (i > 0)
                    {
                        for (int ii = 0; ii < vg.GetLength(0); ii++)
                        {
                            for (int j = 0; j < vg.GetLength(1); j++)
                            {
                                double vvgg = vg[ii, j];
                                if (vg[ii, j] > 65)
                                    vvgg = 0;
                                double vvgg2 = dbz[ii, j];
                                if (dbz[ii, j] > 65)
                                    vvgg2 = 0;

                                double Z = Math.Pow(10, 0.1 * vvgg);
                                double h = (hg[ii, j]);
                                double z2 = Math.Pow(10, 0.1 * vvgg2);
                                double h2 = dbzhg[ii, j];
                                double sumz = Math.Pow((Z + z2) / 2, 4.0 / 7.0);
                                //if ((vg[511 - ii, j] + dbz[ii, j]) == 0)
                                //    sumz = 0;
                                vil[ii, j] = vil[ii, j] + sumz * Math.Abs(h2 - h);

                                //∫_EB^ET▒Z^(4/7)  dh
                            }
                        }
                    }
                    //  Data2Image24(vg, NxtDataCode.Ref).Save("leida" + i + ".jpg");
                    for (int ii = 0; ii < vg.GetLength(0); ii++)
                    {
                        for (int j = 0; j < vg.GetLength(1); j++)
                        {

                            dbz[ii, j] = vg[ii, j];

                            dbzhg[ii, j] = (hg[ii, j]);

                        }
                    }

                }

                //  vil = clockwise(vil, vil.GetLength(0));
                for (int ii = 0; ii < vil.GetLength(0); ii++)
                {
                    for (int j = 0; j < vil.GetLength(1); j++)
                    {
                        //  if (vg[511 - ii, j] > dbz[ii, j])
                        vil[ii, j] = Math.Round(vil[ii, j] * 3.44 * 0.001, 2);
                    }
                }
                //dbzhg = clockwise(dbzhg, dbzhg.GetLength(0));
                //IL=3.44×10^(-3) ∑_(i=1)^(N-1)▒〖((Z_i+Z_(i+1))/2)^(4/7) ∆h_i 〗
                //   dbz = THEmedian(dbz);
                rdma.data = vil;
                return rdma;
            }
            catch (Exception e)
            {
                return null;
            }
            //for (var i = 0; i < 512; i++)
            //{
            //    for (var j = 0; j < 512; j++)
            //    {
            //        dbz[j, 512 - i - 1] = dbz[i, j];//将原矩阵顺时针转90度
            //    }
            //}

        }
        /// <summary>
        /// 冰雹指数
        /// </summary>
        /// <returns></returns>
        internal radardatamode getMESH(radardatamode rdSHI)
        {
            radardatamode rdma = new radardatamode();
            rdma.dt = rdSHI.dt;
            rdma.maxlat = rdSHI.maxlat;
            rdma.maxlon = rdSHI.maxlon;
            rdma.minlat = rdSHI.minlat;
            rdma.minlon = rdSHI.minlon;

            double[,] dbz = new double[rdSHI.data.GetLength(0), rdSHI.data.GetLength(1)];
            for (int ii = 0; ii < rdSHI.data.GetLength(0); ii++)
            {
                for (int j = 0; j < rdSHI.data.GetLength(1); j++)
                {
                    if (rdSHI.data[ii, j] > dbz[ii, j])
                        dbz[ii, j] = Math.Round(2.54 * Math.Pow(rdSHI.data[ii, j], 0.5), 1);
                }
            }
            rdma.data = dbz;
            return rdma;

        }
        /// <summary>
        /// 组合反射率
        /// </summary>
        public radardatamode getbCR(radardataBASE rdm, List<double[,]> listdbz, List<double[,]> listhg)
        {

            // string file = @"D:\ld3\Z_RADR_I_Z9375_20190517003000_O_DOR_SA_CAP.bin";
            //Z_RADR_I_Z9375_20190515235400_O_DOR_SA_CAP.bin
            radardatamode rdma = new radardatamode();
            rdma.dt = rdm.dt;
            rdma.maxlat = rdm.maxlat;
            rdma.maxlon = rdm.maxlon;
            rdma.minlat = rdm.minlat;
            rdma.minlon = rdm.minlon;
            rdma.center = rdm.center;
            double[,] dbz = null;
            try
            {
                for (int i = 0; i < rdm.DBZ.Count; i++)
                {
                    double[,] vg = listdbz[i];
                    double[,] hg = listhg[i];
                    // (provider.DataInstance.DataProcessor as RdaFileProcessor).CRefGridData()

                    if (dbz == null)
                        dbz = new double[vg.GetLength(0), vg.GetLength(1)];
                    //  Data2Image24(vg, NxtDataCode.Ref).Save("leida" + i + ".jpg");
                    for (int ii = 0; ii < vg.GetLength(0); ii++)
                    {
                        for (int j = 0; j < vg.GetLength(1); j++)
                        {
                            if (vg[ii, j] > dbz[ii, j])
                                dbz[ii, j] = Math.Round(vg[ii, j], 1);
                        }
                    }

                }
                // dbz = clockwise(dbz, dbz.GetLength(0));
                //   dbz = THEmedian(dbz);
                rdma.data = dbz;
                return rdma;
            }
            catch
            {
                return null;
            }

        }


        /// <summary>
        /// 冰雹概率
        /// </summary>
        /// <returns></returns>
        public radardatamode getPOH(radardataBASE rdm, List<double[,]> listdbz, List<double[,]> listhg, double zorehg = 3.2)
        {
            // string file = @"D:\ld3\Z_RADR_I_Z9375_20190517003000_O_DOR_SA_CAP.bin";
            //Z_RADR_I_Z9375_20190515235400_O_DOR_SA_CAP.bin

            double[,] dbz = null;
            double[,] dbzhg = null;
            try
            {

                radardatamode rdma = new radardatamode();
                rdma.dt = rdm.dt;
                rdma.maxlat = rdm.maxlat;
                rdma.maxlon = rdm.maxlon;
                rdma.minlat = rdm.minlat;
                rdma.minlon = rdm.minlon; rdma.center = rdm.center;
                for (int i = 0; i < 9; i++)
                {
                    double[,] vg = listdbz[i];
                    double[,] hg = listhg[i];
                    // (provider.DataInstance.DataProcessor as RdaFileProcessor).CRefGridData()

                    if (dbz == null)
                    {
                        dbz = new double[vg.GetLength(0), vg.GetLength(1)];
                        dbzhg = new double[vg.GetLength(0), vg.GetLength(1)];
                    }
                    //  Data2Image24(vg, NxtDataCode.Ref).Save("leida" + i + ".jpg");
                    for (int ii = 0; ii < vg.GetLength(0); ii++)
                    {
                        for (int j = 0; j < vg.GetLength(1); j++)
                        {
                            if (vg[ii, j] > dbz[ii, j] && vg[ii, j] >= 45)
                            {
                                dbz[ii, j] = Math.Round(vg[ii, j], 1);
                                dbzhg[ii, j] = Math.Round(hg[ii, j], 3);
                            }
                        }
                    }

                }
                //dbz = clockwise(dbz, dbz.GetLength(0));
                //dbzhg = clockwise(dbzhg, dbzhg.GetLength(0));
                //   dbz = THEmedian(dbz);
                for (int ii = 0; ii < dbz.GetLength(0); ii++)
                {
                    for (int j = 0; j < dbz.GetLength(1); j++)
                    {
                        if (dbz[ii, j] != 0)
                            dbz[ii, j] = getphobyh0(dbzhg[ii, j], zorehg);
                    }
                }

                rdma.data = dbz;
                return rdma;
            }
            catch
            {
                return null;
            }
            //for (var i = 0; i < 512; i++)
            //{
            //    for (var j = 0; j < 512; j++)
            //    {
            //        dbz[j, 512 - i - 1] = dbz[i, j];//将原矩阵顺时针转90度
            //    }
            //}

        }
        /// <summary>
        /// 冰雹指数
        /// </summary>
        /// <returns></returns>
        public radardatamode getSHI(radardataBASE rdm, List<double[,]> listdbz, List<double[,]> listhg, double ht0, double hmt20)
        {

            // string file = @"D:\ld3\Z_RADR_I_Z9375_20190517003000_O_DOR_SA_CAP.bin";
            //Z_RADR_I_Z9375_20190515235400_O_DOR_SA_CAP.bin

            double[,] dbz = null;
            double[,] dbzhg = null;
            try
            {
                //SHI=1/10 ∫_(H_0)^(H_T)▒〖W_z∙W_h∙E〗 dh


                radardatamode rdma = new radardatamode();
                rdma.dt = rdm.dt;
                rdma.maxlat = rdm.maxlat;
                rdma.maxlon = rdm.maxlon;
                rdma.minlat = rdm.minlat;
                rdma.minlon = rdm.minlon; rdma.center = rdm.center;
                double dbzlo = 40, dbzup = 50;
                double[,] dhsum = null, vsum = null;
                int laye = 0;
                for (int i = 0; i < 9; i++)
                {
                    laye++;
                    double[,] vg = listdbz[i];
                    double[,] hg = listhg[i];
                    // (provider.DataInstance.DataProcessor as RdaFileProcessor).CRefGridData()

                    if (dbz == null)
                    {
                        dbz = new double[vg.GetLength(0), vg.GetLength(1)];
                        dbzhg = new double[vg.GetLength(0), vg.GetLength(1)];

                        dhsum = new double[vg.GetLength(0), vg.GetLength(1)];
                        vsum = new double[vg.GetLength(0), vg.GetLength(1)];
                    }
                    //  Data2Image24(vg, NxtDataCode.Ref).Save("leida" + i + ".jpg");

                    for (int ii = 0; ii < vg.GetLength(0); ii++)
                    {

                        for (int j = 0; j < vg.GetLength(1); j++)
                        {
                            if (vg[ii, j] > dbz[ii, j])
                            {
                                dbz[ii, j] = Math.Round(vg[ii, j], 1);
                                dbzhg[ii, j] = Math.Round(hg[ii, j], 3);
                                double h = dbzhg[ii, j];
                                //  double dh = Math.Abs(h - ht0) / 1000;  // km 
                                double dh = Math.Abs(h - ht0);  // km 
                                double wh = Wh(h, ht0, hmt20);      // 高度权重
                                double wz = Wz(dbz[ii, j], dbzlo, dbzup);  // 回波权重
                                double ehail = Hailenergy(dbz[ii, j]);     // 降雹动能

                                dhsum[ii, j] += dh;
                                vsum[ii, j] += wh * wz * ehail * dh;     // 积分

                                //  hasvalue = true;

                            }
                        }
                    }

                }

                for (int ii = 0; ii < dbz.GetLength(0); ii++)
                {
                    for (int j = 0; j < dbz.GetLength(1); j++)
                    {
                        if (vsum[ii, j] != 0)
                            vsum[ii, j] = vsum[ii, j] / laye;
                    }
                }

                rdma.data = vsum;
                return rdma;
            }
            catch
            {
                return null;
            }

        }
        /// <summary>
        /// 回波权重
        /// </summary>
        /// <param name="dbz">雷达回波反射率（dBZ）</param>
        /// <param name="dbzt_lw">雷达回波反射率阈值下限（dBZ）</param>
        /// <param name="dbzt_up">雷达回波反射率阈值上限（dBZ）</param>
        /// <returns></returns>
        private double Wz(double dbz, double dbzt_lw, double dbzt_up)
        {
            double z1 = dbzt_lw;  // 40dbz
            double z2 = dbzt_up;  // 50dbz

            double wz = dbz <= z1 ? 0
                : dbz >= z2 ? 1
                : (dbz - z1) / (z2 - z1)
                ;

            return wz;
        }
        /// <summary>
        /// 高度权重
        /// </summary>
        /// <param name="h">回波高度（米）</param>
        /// <param name="ht0">0℃层高度（米）</param>
        /// <param name="hmt20">-20℃层高度（米）</param>
        /// <returns></returns>
        private double Wh(double h, double ht0, double hmt20)
        {
            double h1 = ht0;    // 0℃层高度
            double h2 = hmt20;  // -20℃层高度

            double wh = h <= h1 ? 0
                : h >= h2 ? 1
                : (h - h1) / (h2 - h1)
                ;

            return wh;
        }
        /// <summary>
        /// 降雹动能
        /// E = 5 * 10^(-6) * Z^0.84
        /// E = 5 * 10^(-6) * 10^(0.084Z)
        /// </summary>
        /// <param name="dbz">雷达回波反射率（dBZ）</param>
        /// <returns></returns>
        private double Hailenergy(double dbz)
        {
            double henergy = 0;

            try
            {
                double z = Math.Pow(10, 0.1 * dbz);
                double henergy1 = z < 0 ? 0 : 5.0e-6 * Math.Pow(z, 0.84);
                //double henergy2 = z < 0 ? 0 : 5.0e-6 * Math.Pow(10, 0.084 * z); // 无穷大
                henergy = henergy1;
            }
            catch (Exception)
            {
            }

            return henergy;
        }

        double getphobyh0(double dbzhg, double zorehg)
        {
            double pho = (dbzhg - zorehg);

            if (pho <= 1.625)
                return 0;
            else if (pho <= 1.875)
                return 0.1;
            else if (pho <= 2.125)
                return 0.2;
            else if (pho <= 2.375)
                return 0.3;
            else if (pho <= 2.625)
                return 0.4;
            else if (pho <= 2.925)
                return 0.5;
            else if (pho <= 3.3)
                return 0.6;
            else if (pho <= 3.75)
                return 0.7;
            else if (pho <= 4.5)
                return 0.8;
            else if (pho <= 5.5)
                return 0.9;
            else if (pho > 5.5)
                return 1;
            return 0;
        }
        double[,] clockwise(double[,] a, int n)
        {
            for (int i = 0; i < n; ++i)
                for (int j = 0; j < n - i; ++j)
                    swap(ref a[i, j], ref a[n - 1 - j, n - 1 - i]);

            for (int i = 0; i < n / 2; ++i)
                for (int j = 0; j < n; ++j)
                    swap(ref a[i, j], ref a[n - 1 - i, j]);
            return a;
        }

        double[,] transpose(double[,] a, int n)
        {
            for (int i = 0; i < n; ++i)
                for (int j = i + 1; j < n; ++j)
                    swap(ref a[i, j], ref a[j, i]);
            for (int i = 0; i < n / 2; ++i)
                for (int j = 0; j < n; ++j)
                    swap(ref a[i, j], ref a[n - 1 - i, j]);
            return a;
        }
        void swap(ref double a, ref double b)
        {
            double t = a;
            a = b;
            b = t;
        }
    }
}
