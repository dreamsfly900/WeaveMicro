﻿using CSharpKit.Maths.PointTracing;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using WeaveHelper;
using static Google.Protobuf.Reflection.SourceCodeInfo.Types;
using static System.Net.Mime.MediaTypeNames;

namespace RadarManage.tool
{

    public class location
    {
        public double lat;
        public double lng;
    }
    public enum FillModes
    {
        ALTERNATE = 1,
        WINDING = 2,
    }


    public class Calaculate
    {

        #region Constants
        public Calaculate(double centLon, double centLat)
        {
            PixelPerKm = 0.998;

            Elevation = 0;
        }

        public const double EarthRadius = 6371.004;         // 地球平均半径，单位：公里(km)
        public const double EarthRadius_Polar = 6356.755;   // EB，地球两极半径，单位：公里(km)
        public const double EarthRadius_Equator = 6373.140; // EA，地球赤道半径，单位：公里(km)
                                                            //地球半径，单位米
        private const double EARTH_RADIUS = 6378.137;
        #endregion

        #region 每公里像素 - PixelPerKm

        /// <summary>
        /// 每公里像素（PPKM）
        /// </summary>
        /// <remarks>
        /// value = 1000 / 距离库长度?
        /// </remarks>
        public Double PixelPerKm { get; set; }

        #endregion

        #region 扫描仰角

        public Double Elevation { get; set; }

        #endregion

        #region 每经度公里

        public Double KmPerLongitude(double CenterLongitude, double CenterLatitude)
        {
            return this.DistanceOfSphere(CenterLongitude, CenterLatitude,
                CenterLongitude + 1.0, CenterLatitude) / Math.Cos(ToRadian(Elevation));

        }

        #endregion

        #region 每纬度公里

        public Double KmPerLatitude(double CenterLongitude, double CenterLatitude)
        {
            return this.DistanceOfSphere(CenterLongitude, CenterLatitude,
                CenterLongitude, CenterLatitude + 1.0) / Math.Cos(ToRadian(Elevation));

        }
        #endregion

        /// <summary>
        /// 矢量算法 点到线段的最短距离
        /// </summary> 
        /// <returns></returns>
        public double PointToSegDist(double x, double y, double x1, double y1, double x2, double y2)
        {

            double cross = (x2 - x1) * (x - x1) + (y2 - y1) * (y - y1);
            if (cross <= 0) return Math.Sqrt((x - x1) * (x - x1) + (y - y1) * (y - y1));

            double d2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);

            if (cross >= d2) return Math.Sqrt((x - x2) * (x - x2) + (y - y2) * (y - y2));

            double r = cross / d2;

            double px = x1 + (x2 - x1) * r;

            double py = y1 + (y2 - y1) * r;

            return Math.Sqrt((x - px) * (x - px) + (py - y1) * (py - y1));

        }

        /// <summary>
        /// 判断是否在误差范围内
        /// </summary>
        /// <param name="point"></param>
        /// <param name="points"></param>
        /// <param name="limitDistance"></param>
        /// <returns></returns>
        public bool InLimitDistance(location point, List<location> points, double limitDistance, out double neardistance)
        {
            neardistance = -999;
            List<double> distance = new List<double>();
            var len = points.Count;
            var maxIndex = len - 1;

            for (int i = 0; i < len; i++)
            {
                //多边形中当前点
                var currentPoint = points[i];
                var nearPoint = maxIndex == i ? points[0] : points[i + 1];

                double a, b, c;
                //经纬坐标系中求两点的距离
                a = GetDistance(point.lng, point.lat, currentPoint.lng, currentPoint.lat);
                b = GetDistance(point.lng, point.lat, nearPoint.lng, nearPoint.lat);
                c = GetDistance(currentPoint.lng, currentPoint.lat, nearPoint.lng, nearPoint.lat);
                if (b * b >= c * c + a * a)
                {
                    if (!double.IsNaN(c))
                        distance.Add(c);

                    continue;
                }
                if (c * c >= b * b + a * a)
                {
                    if (!double.IsNaN(b))
                        distance.Add(b);
                    continue;
                }

                double l = (a + b + c) / 2;     //周长的一半
                double s = Math.Sqrt(l * (l - a) * (l - b) * (l - c));  //海伦公式求面积 
                if (!double.IsNaN(2 * s / a))
                    distance.Add(2 * s / a);
            }
            if (!distance.Any())
            {
                return false;
            }

            var count = distance.Where(s => s < limitDistance).Count();
            if (count > 0)
            {
                neardistance = distance.Min();
                return true;
            }
            return false;
        }

        /// <summary>
        /// 计算两个坐标点之间的距离
        /// </summary>
        /// <param name="firstLatitude">第一个坐标的纬度</param>
        /// <param name="firstLongitude">第一个坐标的经度</param>
        /// <param name="secondLatitude">第二个坐标的纬度</param>
        /// <param name="secondLongitude">第二个坐标的经度</param>
        /// <returns>返回两点之间的距离，单位：公里/千米</returns>
        public double GetDistance(double firstLatitude, double firstLongitude, double secondLatitude, double secondLongitude)
        {
            double firstRadLat = ToRadian(firstLatitude);
            double firstRadLng = ToRadian(firstLongitude);
            double secondRadLat = ToRadian(secondLatitude);
            double secondRadLng = ToRadian(secondLongitude);


            double a = firstRadLat - secondRadLat;
            double b = firstRadLng - secondRadLng;
            double cal = 2 * Math.Asin(Math.Sqrt(Math.Pow(Math.Sin(a / 2), 2) + Math.Cos(firstRadLat)
                * Math.Cos(secondRadLat) * Math.Pow(Math.Sin(b / 2), 2))) * EARTH_RADIUS;
            double result = Math.Round(cal * 10000) / 10000;
            return result;
        }

        /// <summary>
        /// 计算球面距离（km）
        /// </summary>
        /// <param name="dLon0"></param>
        /// <param name="dLat0"></param>
        /// <param name="dLon1"></param>
        /// <param name="dLat1"></param>
        /// <returns></returns>
        public double DistanceOfSphere(double dLon0, double dLat0, double dLon1, double dLat1)
        {
            double dValue = 0;

            // Google
            // A(a1,b1), B(a2,b2)
            // AB球面距离 = R*arccos[cos(b1)*cos(b2)*cos(a1-a2)+sin(b1)sin(b2)] 
            double rlon0 = ToRadian(dLon0);
            double rlat0 = ToRadian(dLat0);
            double rlon1 = ToRadian(dLon1);
            double rlat1 = ToRadian(dLat1);
            double A = Math.Cos(rlat0) * Math.Cos(rlat1) * Math.Cos(rlon0 - rlon1);
            double B = Math.Sin(rlat0) * Math.Sin(rlat1);
            double AB = A + B;
            double acosAB = AB >= 1 ? 0 : Math.Acos(AB);
            double val = EarthRadius * acosAB;

            dValue = val;

            return dValue;
        }

        /// <summary>
        /// 取得方位角（正北方为0）
        /// </summary>
        /// <param name="dLon"></param>
        /// <param name="dLat"></param>
        /// <returns>返回角度值(DEG)</returns>
        public double GetAzimuth(double dLon, double dLat, double CenterLongitude, double CenterLatitude)
        {
            double dValue = 0;

            if (Double.Equals(dLon, CenterLongitude) && Double.Equals(dLat, CenterLatitude))
            {
                // 经纬度相同，方位角为0
                dValue = 0;
            }
            else if (Double.Equals(dLon, CenterLongitude))
            {
                // 经度相同，在垂直方向
                dValue = dLat > CenterLatitude ? 0.0 : 180.0;
            }
            else if (Double.Equals(dLat, CenterLatitude))
            {
                // 纬度相同，在水平方向
                dValue = dLon > CenterLongitude ? 90.0 : 270.0;
            }
            else
            {
                // 注：由于经向和纬向的球面距离不等(华南，经向>纬向)，
                // 故点(1,1)与中心点(0,0)的极角不等45度，而应是略大于45度
                double xx = Math.Abs(dLon - CenterLongitude) * KmPerLongitude(CenterLongitude, CenterLatitude);
                double yy = Math.Abs(dLat - CenterLatitude) * KmPerLatitude(CenterLongitude, CenterLatitude);
                dValue = this.ToDegree(Math.Atan2(xx, yy));

            }

            // 根据象限确定方位角
            dValue =
                dLon > CenterLongitude && dLat > CenterLatitude ? dValue :          //第一象限
                dLon < CenterLongitude && dLat > CenterLatitude ? 360.0 - dValue :  //第二象限
                dLon < CenterLongitude && dLat < CenterLatitude ? 180.0 + dValue :  //第三象限
                dLon > CenterLongitude && dLat < CenterLatitude ? 180.0 - dValue :  //第四象限
                dValue;

            return dValue;
        }

        public double ToRadian(double deg)
        {
            return (deg * Math.PI / 180.0);
        }
        public double ToDegree(double rad)
        {
            return (rad * 180.0 / Math.PI);
        }



        /// <summary>
        /// 计算质心
        /// </summary>
        /// <param name="points"></param>
        /// <returns></returns>
        public static double[] getPolygonAreaCenter(List<TracePoint> points)
        {
            double sum_x = 0;
            double sum_y = 0;
            double sum_area = 0;
            var p1 = points[1];
            //debugger;
            for (var i = 2; i < points.Count; i++)
            {
                TracePoint p2 = points[i];
                double area = Area(points[0], p1, p2);
                sum_area += area;
                sum_x += (points[0].Lon + p1.Lon + p2.Lon) * area;
                sum_y += (points[0].Lat + p1.Lat + p2.Lat) * area;
                p1 = p2;
            }
            var xx = sum_x / sum_area / 3;
            var yy = sum_y / sum_area / 3;
            return new double[] { xx, yy };
        }
        static double Area(TracePoint p0, TracePoint p1, TracePoint p2)
        {
            var area = 0.0;
            area = p0.Lon * p1.Lat + p1.Lon * p2.Lat + p2.Lon * p0.Lat - p1.Lon * p0.Lat - p2.Lon * p1.Lat - p0.Lon * p2.Lat;
            return area / 2;
        }


    }

    public class GISPolygonHelper
    {

        [DllImport("gdi32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr CreatePolygonRgn(System.Drawing.Point[] points, int pointCount, FillModes fillMode);

        [DllImport("gdi32.dll", CharSet = CharSet.Auto)]
        public static extern bool PtInRegion(IntPtr points, int x, int y);

        /// <summary>
        ///  判断坐标点是否在指定区域内
        /// </summary>
        public static bool latlngInPolygon(List<location> latlngs, double lng, double lat)
        {
            bool inside = false;
            int j, k, len2;

            for (j = 0, len2 = latlngs.Count, k = len2 - 1; j < len2; k = j++)
            {
                var l1 = latlngs[j];
                var l2 = latlngs[k];

                if (((l1.lat > lat) != (l2.lat > lat)) &&
                    (lng < (l2.lng - l1.lng) * (lat - l1.lat) / (l2.lat - l1.lat) + l1.lng))
                {
                    inside = !inside;
                }
            }

            return inside;
        }

        /// <summary>
        ///  判断坐标点是否在指定区域内
        /// </summary>
        /// <param name="x">表示的点的X坐标</param>
        /// <param name="y">表示的点的Y坐标</param>
        public static bool isPtInPolygon(List<location> points, double x, double y)
        {
            //x = 111.97946223;
            //y = 33.25723397;
            int times = 10000;
            System.Drawing.Point[] kpts = new System.Drawing.Point[points.Count];
            for (int i = 0; i < points.Count; i++)
            {
                try
                {
                    kpts[i].X = (int)(points[i].lng * times + 0.1);
                    kpts[i].Y = (int)(points[i].lat * times + 0.1);
                }
                catch (Exception ex)
                { }
            }

            IntPtr hRgn = CreatePolygonRgn(kpts, kpts.Length, FillModes.ALTERNATE);
            bool isInSide = PtInRegion(hRgn, (int)(x * times), (int)(y * times));
            if (isInSide)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 判断坐标点是否在多边形内
        /// </summary>
        /// <param name="point"></param>
        /// <param name="pts"></param>
        /// <returns></returns>
        public static bool isPointInPolygon(location point, List<location> pts)
        {

            //检查类型
            if (point == null || pts == null)
                return false;

            var N = pts.Count;
            var boundOrVertex = true; //如果点位于多边形的顶点或边上，也算做点在多边形内，直接返回true
            var intersectCount = 0; //cross points count of x 
            var precision = 2e-10; //浮点类型计算时候与0比较时候的容差
            location p1, p2; //neighbour bound vertices
            var p = point; //测试点
            p1 = pts[0]; //left vertex        
            for (var i = 1; i <= N; ++i)
            {
                //check all rays            
                if (p.lat.Equals(p1.lat) && p.lng.Equals(p1.lng))
                {
                    return boundOrVertex; //p is an vertex
                }

                p2 = pts[i % N]; //right vertex            
                if (p.lat < Math.Min(p1.lat, p2.lat) || p.lat > Math.Max(p1.lat, p2.lat))
                {
                    //ray is outside of our interests                
                    p1 = p2;
                    continue; //next ray left point
                }

                if (p.lat > Math.Min(p1.lat, p2.lat) && p.lat < Math.Max(p1.lat, p2.lat))
                {
                    //ray is crossing over by the algorithm (common part of)
                    if (p.lng <= Math.Max(p1.lng, p2.lng))
                    {
                        //x is before of ray                    
                        if (p1.lat == p2.lat && p.lng >= Math.Min(p1.lng, p2.lng))
                        {
                            //overlies on a horizontal ray
                            return boundOrVertex;
                        }

                        if (p1.lng == p2.lng)
                        {
                            //ray is vertical                        
                            if (p1.lng == p.lng)
                            {
                                //overlies on a vertical ray
                                return boundOrVertex;
                            }
                            else
                            {
                                //before ray
                                ++intersectCount;
                            }
                        }
                        else
                        {
                            //cross point on the left side                        
                            var xinters =
                                (p.lat - p1.lat) * (p2.lng - p1.lng) / (p2.lat - p1.lat) +
                                p1.lng; //cross point of lng                        
                            if (Math.Abs(p.lng - xinters) < precision)
                            {
                                //overlies on a ray
                                return boundOrVertex;
                            }

                            if (p.lng < xinters)
                            {
                                //before ray
                                ++intersectCount;
                            }
                        }
                    }
                }
                else
                {
                    //special case when ray is crossing through the vertex                
                    if (p.lat == p2.lat && p.lng <= p2.lng)
                    {
                        //p crossing over p2                    
                        var p3 = pts[(i + 1) % N]; //next vertex                    
                        if (p.lat >= Math.Min(p1.lat, p3.lat) && p.lat <= Math.Max(p1.lat, p3.lat))
                        {
                            //p.lat lies between p1.lat & p3.lat
                            ++intersectCount;
                        }
                        else
                        {
                            intersectCount += 2;
                        }
                    }
                }
                p1 = p2; //next ray left point
            }

            if (intersectCount % 2 == 0)
            {
                //偶数在多边形外
                return false;
            }
            else
            {
                //奇数在多边形内
                return true;
            }

        }
        /// <summary>
        ///  回转数法判断点是否在多边形内部
        /// </summary>
        /// <param name="p">待判断的点，格式：{ x: X坐标, y: Y坐标 }</param>
        /// <param name="poly">多边形顶点，数组成员的格式同 p</param>
        /// <returns>点 p 和多边形 poly 的几何关系</returns>
        public string windingNumber(PointD p, List<PointD> poly)
        {
            Double px = p.X,
                py = p.Y,
                sum = 0;


            for (int i = 0, l = poly.Count, j = l - 1; i < l; j = i, i++)
            {
                Double sx = poly[i].X,
                    sy = poly[i].Y,
                    tx = poly[j].X,
                    ty = poly[j].Y;

                // 点与多边形顶点重合或在多边形的边上
                if ((sx - px) * (px - tx) >= 0 && (sy - py) * (py - ty) >= 0 && (px - sx) * (ty - sy) == (py - sy) * (tx - sx))
                {
                    return "on";
                }

                // 点与相邻顶点连线的夹角
                var angle = Math.Atan2(sy - py, sx - px) - Math.Atan2(ty - py, tx - px);

                // 确保夹角不超出取值范围（-π 到 π）
                if (angle >= Math.PI)
                {
                    angle = angle - Math.PI * 2;
                }
                else if (angle <= -Math.PI)
                {
                    angle = angle + Math.PI * 2;
                }

                sum += angle;
            }

            // 计算回转数并判断点和多边形的几何关系
            return Math.Round(sum / Math.PI) == 0 ? "out" : "in";
        }

        /**
         * 获取点与直线之间的距离
         * @param p 点
         * @param a 直线上一点
         * @param b 直线上一点
         * @return
         */
        public static double pointToLineDist(location p, location a, location b)
        {
            double ABx = b.lng - a.lng;
            double ABy = b.lat - a.lat;
            double APx = p.lng - a.lng;
            double APy = p.lat - a.lat;

            double AB_AP = ABx * APx + ABy * APy;
            double distAB2 = ABx * ABx + ABy * ABy;

            double Dx = a.lng, Dy = a.lat;
            if (distAB2 != 0)
            {
                double t = AB_AP / distAB2;
                if (t >= 1)
                {
                    Dx = b.lng;
                    Dy = b.lat;
                }
                else if (t > 0)
                {
                    Dx = a.lng + ABx * t;
                    Dy = a.lat + ABy * t;
                }
                else
                {
                    Dx = a.lng;
                    Dy = a.lat;
                }
            }
            double PDx = Dx - p.lng, PDy = Dy - p.lat;
            return Math.Sqrt(PDx * PDx + PDy * PDy);
        }


        /**
         * 获取点与多边形之间最近距离
         * @param point
         * @param points
         * @return 0.0 ：点位于多边形内部  >0.0 : 点与多边形之间的最近距离
         */
        public static double pintoToPolygonMinDist(location point, List<location> points)
        {
            double dist = Double.MaxValue;
            int N = points.Count;
            for (int i = 0, j = N - 1; i < N; j = i++)
            {
                dist = Math.Min(dist, pointToLineDist(point, points[i], points[j]));
            }
            return dist;
        }

    }


    public class GISTools 
    {
        /// <summary>
        /// 获取当前位置位于哪个县区
        /// </summary>
        /// <param name="lng"></param>
        /// <param name="lat"></param>
        /// <returns></returns>
        public static string getPtInArea(double lng, double lat)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory;

            string result = "";
            using (StreamReader srr = new StreamReader(path + "\\" + @"map\config.js", Encoding.UTF8))
            {
                string str = srr.ReadToEnd();
                str = str.Split('=')[1];
                srr.Close();

                JObject joo = JObject.Parse(str);
                IEnumerable<JProperty> properties = joo.Properties();
                foreach (JProperty item in properties)
                {
                    JArray values = (JArray)joo[item.Name]["features"];
                    foreach (object feat in values)
                    {
                        if (feat.ToString().Length < 10)
                        {
                            continue;
                        }
                        JObject joogeo = (JObject)((JObject)feat)["geometry"];
                        List<location> points = new List<location>();
                        if (joogeo.GetValue("type").ToString() == "MultiLineString" || joogeo.GetValue("type").ToString() == "MultiPolygon")//多个polygon
                        {
                            List<List<double[]>> cdlist = JsonConvert.DeserializeObject<List<List<double[]>>>(JsonConvert.SerializeObject(joogeo["coordinates"])); //获取最大数量的一组点集
                            cdlist = cdlist.OrderByDescending(p => p.Count).ToList();
                            foreach (double[] poi in cdlist[0])
                            {
                                points.Add(new location() { lng = (double)poi[0], lat = (double)poi[1] });
                            }
                        }
                        else
                        {
                            JArray list = (JArray)((JArray)joogeo["coordinates"])[0];
                            foreach (JArray poi in list)
                            {
                                points.Add(new location() { lng = (double)poi[0], lat = (double)poi[1] });
                            }
                        }
                        bool isInner = GISPolygonHelper.isPtInPolygon(points, lng, lat);
                        if (isInner)
                        {
                            JObject Property = (JObject)((JObject)feat)["properties"];
                            result += Property["Name"].ToString() + "、";
                        }
                    }
                }
                result = result.Trim('、');
            }
            return result;
        }
    }

}
