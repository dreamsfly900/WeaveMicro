﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using WeaveHelper;

namespace wContourDemo
{
    public class DiscreteData
    {
        double lng;
        double lat;
        double data;

        public double Lng
        {
            get
            {
                return lng;
            }

            set
            {
                lng = value;
            }
        }
        public double Lat
        {
            get
            {
                return lat;
            }

            set
            {
                lat = value;
            }
        }

        public double Data
        {
            get
            {
                return data;
            }

            set
            {
                data = value;
            }
        }
        public double Data2 { get; set; }
        public string StationNo { get; set; }

    }
    public class streamP
    {
        public double windir { get; set; }
        public double winspeed { get; set; }
        public double clen { get; set; }
        public double sx { get; set; }
        public double sy { get; set; }
    }
    public class PointXYZ
    {
        public double Z { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double H { get; set; }
        public double x { get; set; }
        public double y { get; set; }
        public double U { get; set; }
        public double V { get; set; }
        public double JUli { get; set; }
    }
    public class PointData
    {
        double x;
        double y;
        double z;
        public double X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public double Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }

        public double Z
        {
            get
            {
                return z;
            }
            set
            {
                z = value;
            }
        }
        public double Data2 { get; set; }

    }
    public class shadeguide
    {
        double[] m_CValues;

        public double[] CValues
        {
            get
            {
                return m_CValues;
            }

            set
            {
                m_CValues = value;
            }
        }

        public Color[] Colors
        {
            get
            {
                return m_Colors;
            }

            set
            {
                m_Colors = value;
            }
        }

        Color[] m_Colors;
    }
    [Serializable]
    public struct MapLine
    {
        public List<List<PointD>> mapdata;
        public double maxlng { get; set; }
        public double maxlat { get; set; }
        public double minlng { get; set; }
        public double minlat { get; set; }

    }
    public enum ALG { Neighbour, Radius, Cressman, Streamline };
    public class isoline
    {
        double[] _X = null;
        double[] _Y = null;
        double[] _CValues = null;
        Color[] _colors = null;

        List<List<PointD>> _mapLines = new List<List<PointD>>();

        double _undefData = -9999.0;
        List<List<PointD>> _clipLines = new List<List<PointD>>();

        private double _minX = 0;
        private double _minY = 0;
        private double _maxX = 0;
        private double _maxY = 0;

        private double _scaleX = 1.0;
        private double _scaleY = 1.0;

        public string _dFormat = "0";
        int Width = 1024, Height = 768;
        public string imgType = "";
        public isoline()
        {

        }
        public isoline(int _Width, int _Height)
        {
            Width = _Width;
            Height = _Height;
        }
        public bool Contains(List<PointD> points, PointD p)
        {
            bool result = false;
            for (int i = 0; i < points.Count - 1; i++)
            {
                if ((((points[i + 1].Y <= p.Y) && (p.Y < points[i].Y)) || ((points[i].Y <= p.Y) && (p.Y < points[i + 1].Y))) && (p.X < (points[i].X - points[i + 1].X) * (p.Y - points[i + 1].Y) / (points[i].Y - points[i + 1].Y) + points[i + 1].X))
                {
                    result = !result;
                }
            }
            return result;
        }
        public bool Contains(PointD[] points, PointD p)
        {
            bool result = false;
            for (int i = 0; i < points.Length - 1; i++)
            {
                if ((((points[i + 1].Y <= p.Y) && (p.Y < points[i].Y)) || ((points[i].Y <= p.Y) && (p.Y < points[i + 1].Y))) && (p.X < (points[i].X - points[i + 1].X) * (p.Y - points[i + 1].Y) / (points[i].Y - points[i + 1].Y) + points[i + 1].X))
                {
                    result = !result;
                }
            }
            return result;
        }
        private bool DoubleEquals(double a, double b)
        {
            if (Math.Abs(a - b) < 0.000001)
                return true;
            else
                return false;
        }

        /// <summary>
        /// 坐标转像素
        /// </summary>
        /// <param name="pX"></param>
        /// <param name="pY"></param>
        /// <param name="sX"></param>
        /// <param name="sY"></param>
        public void ToScreen(double pX, double pY, ref double sX, ref double sY)
        {
            sX = (double)((pX - _minX) * _scaleX);
            if (sX < 0)
                sX = 0;
            if (sX >= Width)
                sX = Width - 1;
            sY = (double)((_maxY - pY) * _scaleY);
            if (sY < 0)
                sY = 0;
            if (sY >= Height)
                sY = Height - 1;
        }
        public void ToScreen(double pX, double pY, ref int sX, ref int sY)
        {
            sX = (int)((pX - _minX) * _scaleX);
            sY = (int)((_maxY - pY) * _scaleY);
        }
        /// <summary>
        /// 像素转坐标
        /// </summary>
        /// <param name="sX"></param>
        /// <param name="sY"></param>
        /// <param name="pX"></param>
        /// <param name="pY"></param>
        public void ToCoordinate(int sX, int sY, ref double pX, ref double pY)
        {
            pX = sX / _scaleX + _minX;
            pY = _maxY - sY / _scaleY;
        }

        public void SetCoordinate(int _Width, int _Height, double minX, double maxX, double minY, double maxY)
        {
            _minX = minX;
            _maxX = maxX;
            _minY = minY;
            _maxY = maxY;
            Width = _Width;
            Height = _Height;
            _scaleX = (Width) / (_maxX - _minX);
            _scaleY = (Height) / (_maxY - _minY);
        }
        public void SetCoordinate(double minX, double maxX, double minY, double maxY)
        {
            _minX = minX;
            _maxX = maxX;
            _minY = minY;
            _maxY = maxY;
            _scaleX = (Width) / (_maxX - _minX);
            _scaleY = (Height) / (_maxY - _minY);
            // this.PictureBox1.Refresh();
        }
    }
    public class shadeguide2
    {
        public double[] CValues = new double[0];
        public cl[] Colors = new cl[0];
    }
    public class cl
    {
        int r;

        public int R { get { return r; } set { r = value; } }
        public int G { get { return g; } set { g = value; } }
        public int B { get { return b; } set { b = value; } }

        int g;
        int b;
    }

    public class ColorTemplate
    {
        public static shadeguide2 GetColors(shadeguide sg1, double max, double min, out Bitmap bitmap, string Type)
        {
            Bitmap bmap = new Bitmap(80, 25 * sg1.CValues.Length);
            shadeguide sg = sg1;
            if (Type != "1")
            {
                sg = line(sg1, min, max, Graphics.FromImage(bmap), Type);
            }

            shadeguide2 sg2 = new shadeguide2();
            sg2.Colors = new cl[sg.Colors.Length];
            sg2.CValues = new double[sg.CValues.Length];
            for (int i = 0; i < sg.Colors.Length; i++)
            {
                try
                {
                    cl c = new cl();
                    c.R = sg.Colors[i].R;
                    c.G = sg.Colors[i].G;
                    c.B = sg.Colors[i].B;
                    sg2.Colors[i] = c;
                    sg2.CValues[i] = sg.CValues[i];
                }
                catch { }
            }
            bitmap = bmap;
            String str = Newtonsoft.Json.JsonConvert.SerializeObject(sg2);
            return sg2;
        }

        static shadeguide line(shadeguide sg, double min, double max, Graphics g, string Type)
        {
            List<double> listb = new List<double>();
            List<Color> listbc = new List<Color>();
            int len = sg.Colors.Length;
            double minmax = (max - min) / (len - 1);
            for (int j = 0; j < len - 1; j++)
            {
                Color sourceColor = sg.Colors[j];
                Color destColor = sg.Colors[j + 1];
                int redSpace = destColor.R - sourceColor.R;
                int greenSpace = destColor.G - sourceColor.G;
                int blueSpace = destColor.B - sourceColor.B;

                int s = 0;
                int ls = 25;
                g.DrawString(Math.Round(min, 1).ToString(), new Font("宋体", 10, FontStyle.Regular), Brushes.Black, 40, j * ls + 5);
                double mm = 0;
                for (int i = j * ls; i <= (j * ls) + ls; i++)
                {

                    Color vColor = Color.FromArgb(
                        sourceColor.R + (int)((double)s / ls * redSpace),
                        sourceColor.G + (int)((double)s / ls * greenSpace),
                        sourceColor.B + (int)((double)s / ls * blueSpace)
                    );
                    mm = ((double)min + (double)s / ls * minmax);
                    g.DrawLine(new Pen(vColor), new Point(0, i), new Point(35, i));

                    s++;
                    listb.Add(mm);
                    listbc.Add(vColor);
                }
                min = mm;
                g.DrawLine(new Pen(Color.White), new Point(0, j * ls), new Point(35, j * ls));
            }
            g.Dispose();
            sg.Colors = listbc.ToArray();
            sg.CValues = listb.ToArray();
            return sg;
        }
        /// <summary>
        /// 温度
        /// </summary>
        public static shadeguide Temperature
        {
            get
            {
                shadeguide temp = new shadeguide();
                temp.CValues = new double[] { -16, -12, -8, -6, -4, -2, 0, 2, 4, 6, 8, 12, 16, 20, 24, 26, 28, 30, 32, 35, 37, 38 };
                temp.Colors = new Color[] {
                    Color.FromArgb(7,7,198),
                    Color.FromArgb(8,8,247),
                    Color.FromArgb(8,69,239),
                    Color.FromArgb(8,101,239),
                    Color.FromArgb(8,130,247),
                    Color.FromArgb(8,162,247),
                    Color.FromArgb(8,190,239),
                    Color.FromArgb(8,219,239),
                    Color.FromArgb(24,255,255),
                    Color.FromArgb(24,255,189),
                    Color.FromArgb(24,255,132),
                    Color.FromArgb(24,255,66),
                    Color.FromArgb(132,255,24),
                    Color.FromArgb(156,255,24),
                    Color.FromArgb(189,255,24),
                    Color.FromArgb(222,255,24),
                    Color.FromArgb(255,231,24),
                    Color.FromArgb(255,203,24),
                    Color.FromArgb(255,170,24),
                    Color.FromArgb(255,142,24),
                    Color.FromArgb(255,113,24),
                    Color.FromArgb(255,81,24),
                    Color.FromArgb(255,60,24)
                };
                return temp;
            }
        }
        public static shadeguide Temperature1
        {
            get
            {
                shadeguide temp = new shadeguide();
                temp.CValues = new double[] { -30, -28, -26, -24, -22, -20, -18, -16, -14, -12, -10, -8, -6, -4, -2, 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 35, 37, 40, 45 };
                temp.Colors = new Color[] {
                    Color.FromArgb(0,0,49), Color.FromArgb(7,30,120), Color.FromArgb(17,49,139), Color.FromArgb(27,68,159),
                    Color.FromArgb(38,87,179), Color.FromArgb(48,106,199), Color.FromArgb(59,126,219),Color.FromArgb(78,138,221),
                    Color.FromArgb(97,150,224), Color.FromArgb(116,163,226),Color.FromArgb(135,175,229), Color.FromArgb(155,188,232),
                    Color.FromArgb(154,196,220),Color.FromArgb(153,205,208), Color.FromArgb(152,214,196), Color.FromArgb(151,232,173),
                    Color.FromArgb(215,222,126), Color.FromArgb(234,219,112), Color.FromArgb(244,217,99),Color.FromArgb(250,204,79),
                    Color.FromArgb(247,180,45), Color.FromArgb(242,155,0), Color.FromArgb(241,147,3), Color.FromArgb(240,132,10), Color.FromArgb(239,117,17),
                    Color.FromArgb(238,102,24), Color.FromArgb(238,88,31), Color.FromArgb(231,75,26), Color.FromArgb(224,63,22), Color.FromArgb(217,51,18), Color.FromArgb(208,36,14),
                    Color.FromArgb(194,0,3), Color.FromArgb(181,1,9), Color.FromArgb(169,2,16),Color.FromArgb(138,5,25),Color.FromArgb(80,0,15),
                };
                return temp;
            }
        }
        /// <summary>
        /// 风速
        /// </summary>
        public static shadeguide Windspeed
        {
            get
            {
                shadeguide temp = new shadeguide();

                temp.CValues = new double[] { 0, 1, 2, 3, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22 };
                temp.Colors = new Color[] { Color.FromArgb(163, 255, 113), Color.FromArgb(86, 253, 0), Color.FromArgb(80, 227, 0), Color.FromArgb(68, 196, 0), Color.FromArgb(205, 253, 7), Color.FromArgb(251, 255, 6), Color.FromArgb(254, 249, 0), Color.FromArgb(255, 198, 3), Color.FromArgb(248, 135, 7), Color.FromArgb(255, 73, 4), Color.FromArgb(245, 5, 8), Color.FromArgb(196, 91, 0), Color.FromArgb(130, 0, 4), Color.FromArgb(113, 37, 5) };
                return temp;
            }
        }
        public static shadeguide MaxWindV
        {
            get
            {
                shadeguide temp = new shadeguide();

                temp.CValues = new double[] { 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.6, 37, 41.4, 46.1, 50.9, 56.0, 61.2 };
                temp.Colors = new Color[] {
                    Color.FromArgb(0,255,255,0),
                    Color.FromArgb(230, 246, 234),
                    //Color.FromArgb(211, 245, 221),
                    Color.FromArgb(187, 245, 202),
                    Color.FromArgb(151, 232, 173),
                    Color.FromArgb(153, 210, 202),
                    Color.FromArgb(155, 188,232),
                    Color.FromArgb(107, 157, 225),
                    Color.FromArgb(59, 126, 219),
                    Color.FromArgb(43, 92, 194),
                    Color.FromArgb(28, 59, 169),
                    Color.FromArgb(17, 44, 144),
                    Color.FromArgb(7, 30, 120),
                    Color.FromArgb(30, 6 ,79),
                    Color.FromArgb(70, 25 ,129),
                    Color.FromArgb(134, 21, 138),
                    Color.FromArgb(200, 17, 169)
                };
                return temp;
            }
        }
        public static shadeguide WindV
        {
            get
            {
                shadeguide temp = new shadeguide();

                temp.CValues = new double[] { 0.2, 1.5, 3.3, 5.4, 7.9, 10.7, 13.8, 17.1, 20.7, 24.4, 28.4, 32.6 };// , 36.9, 41.4, 46.1, 50.9
                temp.Colors = new Color[] { Color.FromArgb(255, 248, 250), Color.FromArgb(255, 237, 238), Color.FromArgb(255, 187, 193), Color.FromArgb(255, 153, 153), Color.FromArgb(255, 103, 103), Color.FromArgb(255, 33, 33), Color.FromArgb(240, 0, 0), Color.FromArgb(203, 0, 0), Color.FromArgb(170, 0, 0), Color.FromArgb(114, 0, 0), Color.FromArgb(94, 0, 0), Color.FromArgb(68, 0, 0), };
                return temp;
            }
        }
        /// <summary>
        /// 一小时雨量色标  
        /// 用于24小时、12小时及6小时降雨量
        /// </summary>
        public static shadeguide Rainfall1Hour
        {
            get
            {
                shadeguide temp = new shadeguide();
                temp.CValues = new double[] { 0.1, 9.9, 24.9, 49.9, 99.9, 249.9, 500 };
                temp.Colors = new Color[] { 
                    Color.FromArgb(255, 255, 255), Color.FromArgb(165,243,141), Color.FromArgb(62, 185, 63),
                    Color.FromArgb(99, 184, 255), Color.FromArgb(0, 0, 255), Color.FromArgb(255, 0, 255), Color.FromArgb(128,0,64)
                };
                return temp;
            }
        }
        /// <summary>
        /// 湿度
        /// </summary>
        public static shadeguide Humidity
        {
            get
            {
                shadeguide temp = new shadeguide();
                temp.CValues = new double[] { 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };
                temp.Colors = new Color[] {
                    Color.FromArgb(165, 10, 26), Color.FromArgb(199, 74, 18),
                    Color.FromArgb(235, 111, 34), Color.FromArgb(251, 155, 52),
                    Color.FromArgb(255, 233, 161),Color.FromArgb(233, 247, 255),
                    Color.FromArgb(213, 229, 239),Color.FromArgb(171, 217, 235),
                    Color.FromArgb(68, 147, 199),Color.FromArgb(69,117,181),
                    Color.FromArgb(39, 14, 201),
                };
                return temp;
            }
        }
        /// <summary>
        /// 气压 #5B004D,#9C0086,#D400B3,#FF1AE5,#FF9AF7,#FFDCFF,#D1FCCB,#85F372,#2ED616,#24A312,#145C0A
        /// </summary>
        public static shadeguide StationPress
        {
            get
            {
                shadeguide temp = new shadeguide();
                temp.CValues = new double[] { 904, 908, 912, 916, 920, 924, 928, 932, 936, 940, 944, 948, 952, 956, 960, 964, 968, 972, 976, 980, 984, 988, 992, 996, 1000, 1004, 1008, 1012, 1016, 1020 };
                temp.Colors = new Color[] {
                    Color.FromArgb(189,36,255), Color.FromArgb(156,36,255), Color.FromArgb(165,60,255),
                    Color.FromArgb(173,85,255), Color.FromArgb(181,105,255), Color.FromArgb(206,134,255),
                    Color.FromArgb(206,150,255), Color.FromArgb(231,186,255),Color.FromArgb(90,182,255),
                    Color.FromArgb(123,199,255), Color.FromArgb(156,207,255), Color.FromArgb(181,215,255),
                    Color.FromArgb(214,231,255), Color.FromArgb(198,255,255), Color.FromArgb(156,251,255),
                    Color.FromArgb(107,247,255), Color.FromArgb(66,243,255), Color.FromArgb(33,255,239),
                    Color.FromArgb(33,255,206), Color.FromArgb(33,255,148), Color.FromArgb(33,255,115),
                    Color.FromArgb(41,255,49), Color.FromArgb(90,255,33), Color.FromArgb(165,255,33),
                    Color.FromArgb(198,255,33), Color.FromArgb(239,255,33), Color.FromArgb(255,239,33),
                    Color.FromArgb(255,203,33), Color.FromArgb(255,166,33),Color.FromArgb(255,134,33), Color.FromArgb(255,109,33)
                };
                return temp;
            }
        }
    }

}